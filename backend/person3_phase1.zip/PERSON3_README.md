# Person 3 - Phase 1 (T3.1 - T3.3): Catalog, Plans, Versioning

## Where to copy
- `src/main/java/com/subscriptiontracker/catalog/*`  -> your project (T3.1)
- `src/main/java/com/subscriptiontracker/plan/*`     -> your project (T3.2, T3.3)
- `src/main/resources/db/migration/V3__catalog_and_plans.sql` -> rename V-number to fit yours

## Adjust to your repo
1. Package: find/replace `com.subscriptiontracker` with your real base package.
2. DB: SQL is PostgreSQL. If you use MySQL, change BIGSERIAL to BIGINT AUTO_INCREMENT.
   If you use hibernate ddl-auto instead of Flyway, skip the SQL file.
3. Needs: spring-boot-starter-web, -data-jpa, -validation, -security (method security enabled
   with @EnableMethodSecurity). Roles must be named ROLE_ADMIN.

## Endpoints
Products: GET/POST /api/products, GET/PUT/DELETE /api/products/{id},
          GET/POST /api/products/{id}/variants, PUT /api/products/variants/{variantId}
Plans:    GET/POST /api/plans, GET /api/plans/{id}, GET /api/plans/{id}/current-version,
          PUT /api/plans/{id}/draft, POST /api/plans/{id}/versions,
          POST /api/plans/{id}/publish, POST /api/plans/{id}/retire
(All writes are ADMIN only.)

## Rules implemented
- Published plan -> POST /versions inserts version N+1; old rows never edited.
- Publish requires price, billingCycle, effectiveFrom (and effectiveTo >= effectiveFrom).
- Retire blocks new subscriptions only; active ones keep their plan_version_id.
- Money is in paise (long). No floats.

## For later tasks
- Subscription creation (T3.5) should call PlanService.currentVersion(planId, date)
  and store the returned version id as plan_version_id.
