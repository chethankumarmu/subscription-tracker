-- Person 3: T3.1 - T3.3 (PostgreSQL). Rename V3 if your Flyway numbering differs.
CREATE TABLE products (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    code        VARCHAR(50)  NOT NULL UNIQUE,
    description TEXT,
    active      BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE product_variants (
    id          BIGSERIAL PRIMARY KEY,
    product_id  BIGINT       NOT NULL REFERENCES products(id),
    name        VARCHAR(150) NOT NULL,
    sku         VARCHAR(80)  NOT NULL UNIQUE,
    price_delta BIGINT       NOT NULL DEFAULT 0   -- paise
);

CREATE TABLE plans (
    id         BIGSERIAL PRIMARY KEY,
    code       VARCHAR(50)  NOT NULL UNIQUE,
    name       VARCHAR(150) NOT NULL,
    product_id BIGINT       NOT NULL REFERENCES products(id),
    status     VARCHAR(20)  NOT NULL DEFAULT 'DRAFT'
               CHECK (status IN ('DRAFT','PUBLISHED','RETIRED'))
);

CREATE TABLE plan_versions (
    id                 BIGSERIAL PRIMARY KEY,
    plan_id            BIGINT      NOT NULL REFERENCES plans(id),
    version_number     INT         NOT NULL,
    price              BIGINT,                    -- paise; required before publish
    billing_cycle      VARCHAR(20)
                       CHECK (billing_cycle IN ('DAILY','WEEKLY','MONTHLY','YEARLY')),
    min_quantity       INT         NOT NULL DEFAULT 1,
    effective_from     DATE,
    effective_to       DATE,
    auto_close         BOOLEAN     NOT NULL DEFAULT FALSE,
    allow_early_close  BOOLEAN     NOT NULL DEFAULT FALSE,
    allow_pause        BOOLEAN     NOT NULL DEFAULT FALSE,
    allow_renewal      BOOLEAN     NOT NULL DEFAULT TRUE,
    UNIQUE (plan_id, version_number)
);

CREATE TABLE plan_limits (
    id              BIGSERIAL PRIMARY KEY,
    plan_version_id BIGINT      NOT NULL REFERENCES plan_versions(id),
    limit_key       VARCHAR(60) NOT NULL,         -- users, storage_gb, api_calls
    limit_value     BIGINT      NOT NULL,
    UNIQUE (plan_version_id, limit_key)
);
