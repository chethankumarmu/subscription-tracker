package com.subscriptiontracker.catalog;

import com.subscriptiontracker.catalog.CatalogDtos.ProductRequest;
import com.subscriptiontracker.catalog.CatalogDtos.VariantRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final CatalogService service;

    public ProductController(CatalogService service) { this.service = service; }

    @GetMapping
    public List<Product> list(@RequestParam(defaultValue = "false") boolean activeOnly) {
        return service.listProducts(activeOnly);
    }

    @GetMapping("/{id}")
    public Product get(@PathVariable Long id) { return service.getProduct(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public Product create(@Valid @RequestBody ProductRequest r) { return service.createProduct(r); }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Product update(@PathVariable Long id, @Valid @RequestBody ProductRequest r) {
        return service.updateProduct(id, r);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('ADMIN')")
    public void deactivate(@PathVariable Long id) { service.deactivateProduct(id); }

    @GetMapping("/{id}/variants")
    public List<ProductVariant> variants(@PathVariable Long id) { return service.listVariants(id); }

    @PostMapping("/{id}/variants")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public ProductVariant addVariant(@PathVariable Long id, @Valid @RequestBody VariantRequest r) {
        return service.addVariant(id, r);
    }

    @PutMapping("/variants/{variantId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ProductVariant updateVariant(@PathVariable Long variantId, @Valid @RequestBody VariantRequest r) {
        return service.updateVariant(variantId, r);
    }
}
