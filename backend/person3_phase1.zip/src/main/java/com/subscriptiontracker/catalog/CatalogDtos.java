package com.subscriptiontracker.catalog;

import jakarta.validation.constraints.NotBlank;

public final class CatalogDtos {
    private CatalogDtos() {}

    public record ProductRequest(@NotBlank String name, @NotBlank String code,
                                 String description, Boolean active) {}

    public record VariantRequest(@NotBlank String name, @NotBlank String sku, Long priceDelta) {}
}
