package com.subscriptiontracker.catalog;

import com.subscriptiontracker.catalog.CatalogDtos.ProductRequest;
import com.subscriptiontracker.catalog.CatalogDtos.VariantRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Transactional
public class CatalogService {
    private final ProductRepository products;
    private final ProductVariantRepository variants;

    public CatalogService(ProductRepository products, ProductVariantRepository variants) {
        this.products = products;
        this.variants = variants;
    }

    @Transactional(readOnly = true)
    public List<Product> listProducts(boolean activeOnly) {
        return activeOnly ? products.findByActiveTrue() : products.findAll();
    }

    @Transactional(readOnly = true)
    public Product getProduct(Long id) {
        return products.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));
    }

    public Product createProduct(ProductRequest r) {
        if (products.existsByCode(r.code()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Product code already exists");
        Product p = new Product();
        p.setName(r.name());
        p.setCode(r.code());
        p.setDescription(r.description());
        p.setActive(r.active() == null || r.active());
        return products.save(p);
    }

    public Product updateProduct(Long id, ProductRequest r) {
        Product p = getProduct(id);
        if (!p.getCode().equals(r.code()) && products.existsByCode(r.code()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Product code already exists");
        p.setName(r.name());
        p.setCode(r.code());
        p.setDescription(r.description());
        if (r.active() != null) p.setActive(r.active());
        return products.save(p);
    }

    /** Soft delete: plans/subscriptions may still reference the product. */
    public void deactivateProduct(Long id) {
        Product p = getProduct(id);
        p.setActive(false);
        products.save(p);
    }

    @Transactional(readOnly = true)
    public List<ProductVariant> listVariants(Long productId) {
        getProduct(productId);
        return variants.findByProductId(productId);
    }

    public ProductVariant addVariant(Long productId, VariantRequest r) {
        getProduct(productId);
        if (variants.existsBySku(r.sku()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "SKU already exists");
        ProductVariant v = new ProductVariant();
        v.setProductId(productId);
        v.setName(r.name());
        v.setSku(r.sku());
        v.setPriceDelta(r.priceDelta() == null ? 0 : r.priceDelta());
        return variants.save(v);
    }

    public ProductVariant updateVariant(Long variantId, VariantRequest r) {
        ProductVariant v = variants.findById(variantId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Variant not found"));
        if (!v.getSku().equals(r.sku()) && variants.existsBySku(r.sku()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "SKU already exists");
        v.setName(r.name());
        v.setSku(r.sku());
        v.setPriceDelta(r.priceDelta() == null ? 0 : r.priceDelta());
        return variants.save(v);
    }
}
