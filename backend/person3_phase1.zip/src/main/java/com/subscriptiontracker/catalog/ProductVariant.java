package com.subscriptiontracker.catalog;

import jakarta.persistence.*;

@Entity
@Table(name = "product_variants")
public class ProductVariant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "product_id", nullable = false) private Long productId;
    @Column(nullable = false) private String name;
    @Column(nullable = false, unique = true) private String sku;
    @Column(name = "price_delta", nullable = false) private long priceDelta; // paise

    public Long getId() { return id; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public long getPriceDelta() { return priceDelta; }
    public void setPriceDelta(long priceDelta) { this.priceDelta = priceDelta; }
}
