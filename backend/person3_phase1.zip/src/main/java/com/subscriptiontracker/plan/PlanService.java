package com.subscriptiontracker.plan;

import com.subscriptiontracker.catalog.ProductRepository;
import com.subscriptiontracker.plan.PlanDtos.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * T3.2 / T3.3 - plan identity vs. version separation.
 * Rule: a PUBLISHED plan's version rows are never edited. Changes create version N+1.
 * The "current" version is resolved by date, so old rows stay untouched.
 */
@Service
@Transactional
public class PlanService {
    private final PlanRepository plans;
    private final PlanVersionRepository versions;
    private final PlanLimitRepository limits;
    private final ProductRepository products;

    public PlanService(PlanRepository plans, PlanVersionRepository versions,
                       PlanLimitRepository limits, ProductRepository products) {
        this.plans = plans;
        this.versions = versions;
        this.limits = limits;
        this.products = products;
    }

    // ---------- create / edit ----------

    public PlanDetail create(PlanCreateRequest r) {
        if (plans.existsByCode(r.code()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Plan code already exists");
        if (!products.existsById(r.productId()))
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found");

        Plan p = new Plan();
        p.setCode(r.code());
        p.setName(r.name());
        p.setProductId(r.productId());
        p.setStatus(PlanStatus.DRAFT);
        p = plans.save(p);

        PlanVersion v = new PlanVersion();
        v.setPlanId(p.getId());
        v.setVersionNumber(1);
        if (r.version() != null) apply(v, r.version());
        v = versions.save(v);
        if (r.version() != null) saveLimits(v.getId(), r.version().limits());
        return detail(p);
    }

    /** Draft plans have not been sold yet, so editing the latest version in place is safe. */
    public PlanDetail updateDraft(Long planId, VersionRequest r) {
        Plan p = getPlan(planId);
        if (p.getStatus() != PlanStatus.DRAFT)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Only DRAFT plans can be edited in place; create a new version instead");
        PlanVersion v = latest(planId);
        apply(v, r);
        versions.save(v);
        if (r.limits() != null) {
            limits.deleteByPlanVersionId(v.getId());
            saveLimits(v.getId(), r.limits());
        }
        return detail(p);
    }

    /** Never mutates old rows: inserts version N+1, inheriting any field not supplied. */
    public PlanDetail newVersion(Long planId, VersionRequest r) {
        Plan p = getPlan(planId);
        if (p.getStatus() != PlanStatus.PUBLISHED)
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "New versions can only be created for PUBLISHED plans");
        PlanVersion prev = latest(planId);

        PlanVersion nv = new PlanVersion();
        nv.setPlanId(planId);
        nv.setVersionNumber(prev.getVersionNumber() + 1);
        nv.setPrice(prev.getPrice());
        nv.setBillingCycle(prev.getBillingCycle());
        nv.setMinQuantity(prev.getMinQuantity());
        nv.setEffectiveFrom(prev.getEffectiveFrom());
        nv.setEffectiveTo(prev.getEffectiveTo());
        nv.setAutoClose(prev.isAutoClose());
        nv.setAllowEarlyClose(prev.isAllowEarlyClose());
        nv.setAllowPause(prev.isAllowPause());
        nv.setAllowRenewal(prev.isAllowRenewal());
        apply(nv, r);

        if (r.effectiveFrom() == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "effectiveFrom is required for a new version");
        if (prev.getEffectiveFrom() != null && nv.getEffectiveFrom().isBefore(prev.getEffectiveFrom()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "effectiveFrom cannot be earlier than the previous version's");
        requireReady(nv);

        nv = versions.save(nv);
        Map<String, Long> newLimits = r.limits() != null ? r.limits() : limitMap(prev.getId());
        saveLimits(nv.getId(), newLimits);
        return detail(p);
    }

    // ---------- lifecycle ----------

    public PlanDetail publish(Long planId) {
        Plan p = getPlan(planId);
        if (p.getStatus() != PlanStatus.DRAFT)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Only DRAFT plans can be published");
        requireReady(latest(planId));
        p.setStatus(PlanStatus.PUBLISHED);
        plans.save(p);
        return detail(p);
    }

    /** Blocks NEW subscriptions only. Existing subscriptions keep their plan_version_id. */
    public PlanDetail retire(Long planId) {
        Plan p = getPlan(planId);
        if (p.getStatus() != PlanStatus.PUBLISHED)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Only PUBLISHED plans can be retired");
        p.setStatus(PlanStatus.RETIRED);
        plans.save(p);
        return detail(p);
    }

    // ---------- reads ----------

    @Transactional(readOnly = true)
    public List<Plan> list() { return plans.findAll(); }

    @Transactional(readOnly = true)
    public PlanDetail get(Long planId) { return detail(getPlan(planId)); }

    /** The version a NEW subscription should use on the given date. */
    @Transactional(readOnly = true)
    public VersionDetail currentVersion(Long planId, LocalDate on) {
        Plan p = getPlan(planId);
        if (p.getStatus() != PlanStatus.PUBLISHED)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Plan is not available for new subscriptions");
        return versions.findByPlanIdOrderByVersionNumberDesc(planId).stream()
                .filter(v -> v.getEffectiveFrom() != null && !v.getEffectiveFrom().isAfter(on))
                .filter(v -> v.getEffectiveTo() == null || !v.getEffectiveTo().isBefore(on))
                .findFirst()
                .map(v -> new VersionDetail(v, limitMap(v.getId())))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No plan version is effective on " + on));
    }

    // ---------- helpers ----------

    private Plan getPlan(Long id) {
        return plans.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Plan not found"));
    }

    private PlanVersion latest(Long planId) {
        return versions.findFirstByPlanIdOrderByVersionNumberDesc(planId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Plan has no versions"));
    }

    private void apply(PlanVersion v, VersionRequest r) {
        if (r.price() != null) v.setPrice(r.price());
        if (r.billingCycle() != null) v.setBillingCycle(r.billingCycle());
        if (r.minQuantity() != null) v.setMinQuantity(r.minQuantity());
        if (r.effectiveFrom() != null) v.setEffectiveFrom(r.effectiveFrom());
        if (r.effectiveTo() != null) v.setEffectiveTo(r.effectiveTo());
        if (r.autoClose() != null) v.setAutoClose(r.autoClose());
        if (r.allowEarlyClose() != null) v.setAllowEarlyClose(r.allowEarlyClose());
        if (r.allowPause() != null) v.setAllowPause(r.allowPause());
        if (r.allowRenewal() != null) v.setAllowRenewal(r.allowRenewal());
    }

    /** Publish gate: pricing, billing cycle and validity window must all be set. */
    private void requireReady(PlanVersion v) {
        List<String> missing = new ArrayList<>();
        if (v.getPrice() == null) missing.add("price");
        if (v.getBillingCycle() == null) missing.add("billingCycle");
        if (v.getEffectiveFrom() == null) missing.add("effectiveFrom");
        if (!missing.isEmpty())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Missing: " + String.join(", ", missing));
        if (v.getEffectiveTo() != null && v.getEffectiveTo().isBefore(v.getEffectiveFrom()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "effectiveTo is before effectiveFrom");
    }

    private void saveLimits(Long versionId, Map<String, Long> map) {
        if (map == null) return;
        map.forEach((key, value) -> {
            PlanLimit l = new PlanLimit();
            l.setPlanVersionId(versionId);
            l.setLimitKey(key);
            l.setLimitValue(value);
            limits.save(l);
        });
    }

    private Map<String, Long> limitMap(Long versionId) {
        return limits.findByPlanVersionId(versionId).stream()
                .collect(Collectors.toMap(PlanLimit::getLimitKey, PlanLimit::getLimitValue,
                        (a, b) -> b, LinkedHashMap::new));
    }

    private PlanDetail detail(Plan p) {
        List<VersionDetail> vs = versions.findByPlanIdOrderByVersionNumberDesc(p.getId()).stream()
                .map(v -> new VersionDetail(v, limitMap(v.getId())))
                .toList();
        return new PlanDetail(p, vs);
    }
}
