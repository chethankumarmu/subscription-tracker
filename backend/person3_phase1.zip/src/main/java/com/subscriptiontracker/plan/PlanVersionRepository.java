package com.subscriptiontracker.plan;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface PlanVersionRepository extends JpaRepository<PlanVersion, Long> {
    List<PlanVersion> findByPlanIdOrderByVersionNumberDesc(Long planId);
    Optional<PlanVersion> findFirstByPlanIdOrderByVersionNumberDesc(Long planId);
}
