package com.subscriptiontracker.plan;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlanLimitRepository extends JpaRepository<PlanLimit, Long> {
    List<PlanLimit> findByPlanVersionId(Long planVersionId);
    void deleteByPlanVersionId(Long planVersionId);
}
