package com.subscriptiontracker.plan;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public final class PlanDtos {
    private PlanDtos() {}

    /** Every field optional: drafts may be incomplete; new versions inherit missing fields. */
    public record VersionRequest(
            @PositiveOrZero Long price,
            BillingCycle billingCycle,
            @PositiveOrZero Integer minQuantity,
            LocalDate effectiveFrom,
            LocalDate effectiveTo,
            Boolean autoClose,
            Boolean allowEarlyClose,
            Boolean allowPause,
            Boolean allowRenewal,
            Map<String, Long> limits) {}

    public record PlanCreateRequest(
            @NotBlank String code,
            @NotBlank String name,
            @NotNull Long productId,
            @Valid VersionRequest version) {}

    public record VersionDetail(PlanVersion version, Map<String, Long> limits) {}

    public record PlanDetail(Plan plan, List<VersionDetail> versions) {}
}
