package com.subscriptiontracker.plan;

import com.subscriptiontracker.plan.PlanDtos.*;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/plans")
public class PlanController {
    private final PlanService service;

    public PlanController(PlanService service) { this.service = service; }

    @GetMapping
    public List<Plan> list() { return service.list(); }

    @GetMapping("/{id}")
    public PlanDetail get(@PathVariable Long id) { return service.get(id); }

    /** Version a new subscription would get today (or on ?on=yyyy-MM-dd). */
    @GetMapping("/{id}/current-version")
    public VersionDetail current(@PathVariable Long id,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate on) {
        return service.currentVersion(id, on != null ? on : LocalDate.now());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public PlanDetail create(@Valid @RequestBody PlanCreateRequest r) { return service.create(r); }

    @PutMapping("/{id}/draft")
    @PreAuthorize("hasRole('ADMIN')")
    public PlanDetail updateDraft(@PathVariable Long id, @Valid @RequestBody VersionRequest r) {
        return service.updateDraft(id, r);
    }

    @PostMapping("/{id}/versions")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public PlanDetail newVersion(@PathVariable Long id, @Valid @RequestBody VersionRequest r) {
        return service.newVersion(id, r);
    }

    @PostMapping("/{id}/publish")
    @PreAuthorize("hasRole('ADMIN')")
    public PlanDetail publish(@PathVariable Long id) { return service.publish(id); }

    @PostMapping("/{id}/retire")
    @PreAuthorize("hasRole('ADMIN')")
    public PlanDetail retire(@PathVariable Long id) { return service.retire(id); }
}
