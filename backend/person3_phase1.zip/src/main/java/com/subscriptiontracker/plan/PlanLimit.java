package com.subscriptiontracker.plan;

import jakarta.persistence.*;

@Entity
@Table(name = "plan_limits",
       uniqueConstraints = @UniqueConstraint(columnNames = {"plan_version_id", "limit_key"}))
public class PlanLimit {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "plan_version_id", nullable = false) private Long planVersionId;
    @Column(name = "limit_key", nullable = false) private String limitKey;
    @Column(name = "limit_value", nullable = false) private long limitValue;

    public Long getId() { return id; }
    public Long getPlanVersionId() { return planVersionId; }
    public void setPlanVersionId(Long planVersionId) { this.planVersionId = planVersionId; }
    public String getLimitKey() { return limitKey; }
    public void setLimitKey(String limitKey) { this.limitKey = limitKey; }
    public long getLimitValue() { return limitValue; }
    public void setLimitValue(long limitValue) { this.limitValue = limitValue; }
}
