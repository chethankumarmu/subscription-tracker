package com.subscriptiontracker.plan;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "plan_versions",
       uniqueConstraints = @UniqueConstraint(columnNames = {"plan_id", "version_number"}))
public class PlanVersion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "plan_id", nullable = false) private Long planId;
    @Column(name = "version_number", nullable = false) private int versionNumber;
    private Long price; // paise
    @Enumerated(EnumType.STRING) @Column(name = "billing_cycle") private BillingCycle billingCycle;
    @Column(name = "min_quantity", nullable = false) private int minQuantity = 1;
    @Column(name = "effective_from") private LocalDate effectiveFrom;
    @Column(name = "effective_to") private LocalDate effectiveTo;
    @Column(name = "auto_close", nullable = false) private boolean autoClose;
    @Column(name = "allow_early_close", nullable = false) private boolean allowEarlyClose;
    @Column(name = "allow_pause", nullable = false) private boolean allowPause;
    @Column(name = "allow_renewal", nullable = false) private boolean allowRenewal = true;

    public Long getId() { return id; }
    public Long getPlanId() { return planId; }
    public void setPlanId(Long planId) { this.planId = planId; }
    public int getVersionNumber() { return versionNumber; }
    public void setVersionNumber(int versionNumber) { this.versionNumber = versionNumber; }
    public Long getPrice() { return price; }
    public void setPrice(Long price) { this.price = price; }
    public BillingCycle getBillingCycle() { return billingCycle; }
    public void setBillingCycle(BillingCycle billingCycle) { this.billingCycle = billingCycle; }
    public int getMinQuantity() { return minQuantity; }
    public void setMinQuantity(int minQuantity) { this.minQuantity = minQuantity; }
    public LocalDate getEffectiveFrom() { return effectiveFrom; }
    public void setEffectiveFrom(LocalDate effectiveFrom) { this.effectiveFrom = effectiveFrom; }
    public LocalDate getEffectiveTo() { return effectiveTo; }
    public void setEffectiveTo(LocalDate effectiveTo) { this.effectiveTo = effectiveTo; }
    public boolean isAutoClose() { return autoClose; }
    public void setAutoClose(boolean autoClose) { this.autoClose = autoClose; }
    public boolean isAllowEarlyClose() { return allowEarlyClose; }
    public void setAllowEarlyClose(boolean allowEarlyClose) { this.allowEarlyClose = allowEarlyClose; }
    public boolean isAllowPause() { return allowPause; }
    public void setAllowPause(boolean allowPause) { this.allowPause = allowPause; }
    public boolean isAllowRenewal() { return allowRenewal; }
    public void setAllowRenewal(boolean allowRenewal) { this.allowRenewal = allowRenewal; }
}
