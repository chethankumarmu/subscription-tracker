package com.subscriptiontracker.plan;

public enum PlanStatus { DRAFT, PUBLISHED, RETIRED }
