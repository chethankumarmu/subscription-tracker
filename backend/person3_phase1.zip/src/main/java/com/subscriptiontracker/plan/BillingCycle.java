package com.subscriptiontracker.plan;

public enum BillingCycle { DAILY, WEEKLY, MONTHLY, YEARLY }
